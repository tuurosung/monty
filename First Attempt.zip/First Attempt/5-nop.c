#include "monty.h"


void mnty_nop(stack_t **stack_start, unsigned int ln_num)
{
	(void) ln_num;
	(void) stack_start;
}
