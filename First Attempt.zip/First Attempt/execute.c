#include "monty.h"



int execute(char *content, stack_t **stack, unsigned int ln_num, FILE *file)
{
	instruction_t opst[] = {
				{"push", mnty_push}, {"pall", mnty_pall}, {"pint", mnty_pint},
				{"pop", mnty_pop},
				{"swap", mnty_swap},
				{"add", mnty_add},
				{"nop", mnty_nop},
				{"sub", mnty_sub},
				{"div", mnty_div},
				{"mul", mnty_mul},
				{"mod", mnty_mod},
				{"pchar", mnty_pchar},
				{"pstr", mnty_pstr},
				{"rotl", mnty_rotl},
				{"rotr", mnty_rotr},
				{"queue", mnty_queue},
				{"stack", mnty_stack},
				{NULL, NULL}
				};
	unsigned int i = 0;
	char *op;

	op = strtok(content, " \n\t");
	if (op && op[0] == '#')
		return (0);
	bus.arg = strtok(NULL, " \n\t");
	while (opst[i].opcode && op)
	{
		if (strcmp(op, opst[i].opcode) == 0)
		{	opst[i].f(stack, ln_num);
			return (0);
		}
		i++;
	}
	if (op && opst[i].opcode == NULL)
	{ fprintf(stderr, "L%d: unknown instruction %s\n", ln_num, op);
		fclose(file);
		free(content);
		free_stack(*stack);
		exit(EXIT_FAILURE); }
	return (1);
}
